# EPP-UCA Digital System Specification
## Package C – Issue 01 / Revision 00

### 1. Architecture
- Front end: Streamlit bilingual interface.
- Application layer: Python.
- Prototype database: SQLite.
- Production database recommendation: PostgreSQL or the EPP-approved enterprise database.
- Question library: versioned bilingual JSON/database tables.
- Reporting: PDF/Excel export in a later release.
- AI: optional decision-support service with human review; no autonomous approvals.

### 2. Main modules
1. Dashboard
2. Event Registration
3. Event Classification & Risk-Based Level Selection
4. Immediate Cause Analysis
5. Contributing Factors
6. Barrier Analysis
7. Root Cause Analysis
8. Corrective & Preventive Actions
9. Effectiveness Verification
10. Lessons Learned
11. Question & Option Library Administration
12. Approval and Audit Trail

### 3. Hybrid question engine
- Fixed questions are displayed for each applicable analysis level.
- Adaptive questions are triggered by prior answers.
- Trigger syntax in the prototype: `QUESTION_ID=OPTION_CODE`; multiple acceptable codes separated by commas.
- Unknown and Not Applicable must remain distinct.
- Single-select and multi-select are supported.
- Questions and options must have English and Arabic labels.
- Historical answer snapshots must not change when library labels are revised.

### 4. Roles
Reporter; HSE Analyst; Investigation Leader; Technical Reviewer; Department Manager; HSE Manager; Library Administrator; Management Approver; Read-only Auditor.
Production deployment requires authentication and server-enforced role-based access control.

### 5. Core data entities
- Events
- Questions
- Options
- Answers
- Evidence
- CauseLinks
- Barriers
- Actions
- Verifications
- Approvals
- LibraryProposals
- AuditTrail
- Users and Roles

### 6. Mandatory controls
- Unique event ID.
- Immutable audit history.
- Version-controlled question bank.
- Evidence traceability.
- Separation of duties.
- Approval workflow.
- Reopening and superseding revisions.
- Backup and restore.
- Access control and encryption.
- Retention rules aligned with EPP policy and applicable law.

### 7. AI governance
AI suggestions must be labeled as suggestions, cite the supplied evidence or source records, and require analyst verification. AI cannot create evidence, make final root-cause determinations, approve actions, or close investigations.

### 8. Acceptance criteria
- Bilingual question and option display.
- Fixed and conditional questions behave as configured.
- Multi-select and single-select persist correctly.
- New options enter a pending review queue.
- Event records are retrievable.
- Audit actions are recorded.
- Level 1/2/3 visibility rules are respected.
- Root cause evidence and action linkage can be recorded.
- No production deployment until security, validation, backup, access control and user acceptance testing are completed.

### 9. Pilot boundary
The included Streamlit application is a functional prototype. It is not a validated production HSE application. Review the question bank with EPP HSE, Operations, Maintenance, Engineering and Process Safety before operational use.
